import com.cycling74.max.*;
import java.io.IOException;

public class convertFilename extends MaxObject
{
	static {
		try {
			System.loadLibrary( "MaxMSPFileNameConverterJNILib" );
			System.out.println("MaxMSPFileNameConverterJNILib successfully loaded.");
		} catch (UnsatisfiedLinkError e)
		{	
			if(e.getMessage().indexOf("already") != -1)
			{
				System.out.println("MaxMSPFileNameConverterJNILib already loaded.");
			} else {
				e.printStackTrace();	
			}
		}
	}

static native String getMyFullName(String s);

private static final String[] INLET_ASSIST = new String[]{
"inlet 1 help"
};
private static final String[] OUTLET_ASSIST = new String[]{
"outlet 1 help"
};

public convertFilename(Atom[] args)
{
declareInlets(new int[]{DataTypes.ALL});
declareOutlets(new int[]{DataTypes.ALL});

setInletAssist(INLET_ASSIST);
setOutletAssist(OUTLET_ASSIST);

}

public void convert(String s1)
{	
	//Need to make sure this string does not need to be converted	
	if(s1.matches(".*#[0-9]+\\..*") && s1.matches(".*:.*"))
	{	
		outlet(0,Atom.newAtom(s1));
	}
	else	
	{	
	//	System.out.println("convert: "+s1);
		String s2 = getMyFullName( s1 );
	//	for(int i = 0 ; i < s2.length() ; i++)
	//	{
	//		System.out.println(s2.charAt(i)+" "+s2.codePointAt(i));
	//	}
		s2 = s2.replace(""+((char)14848),":/");
		s2 = s2.replace(""+((char)12032),"/");
	//	System.out.println("result: "+s2);
	   	outlet(0,Atom.newAtom(s2));
	}
}


public void inlet(int i)
{
}

public void inlet(float f)
{
}


public void list(Atom[] list)
{
}

}

















